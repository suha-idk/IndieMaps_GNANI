import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global Tier 1 Google Maps Platform Quota Defense
(window as any).gm_authFailure = () => {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
};
const origError = console.error;
console.error = (...args: unknown[]) => {
  origError.apply(console, args);
  const msg = args
    .map((a) => {
      try {
        return typeof a === 'object' && a !== null ? JSON.stringify(a) : String(a);
      } catch {
        return String(a);
      }
    })
    .join(' ');
  if (msg.includes('OverQuotaMapError') || msg.includes('QuotaExceededError')) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
};

createRoot(document.getElementById('root')!).render(<App />);
